/*
-------------------------------------
File:    mysort.h
Project: Assignment 4
-------------------------------------
Author:  Indu Aujla 
ID:      2104349490
Email:   aujl9490@mylaurier.ca
-------------------------------------
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "mysort.h"
#include "myrecord.h"

#define MAX_LINE 100


char letter_grade(float s)
{
    //declare letter grades and grade ranges
    char g[] = {'S', 'A', 'B', 'C', 'D', 'F'};
    float b[] = {100, 90, 80, 70, 60, 50, 0};

    //declare linear search variables 
    char r = 'S';
    int i = 0;
    int n = sizeof(b)/sizeof(float);
    //Linear search 
    while (i < n-1)
    {
        if ((i==0 || s < b[i]) && s >= b[i+1])
        {
            r = g[i];
            break;
        }
        i++;
    }
    return r;
  
}



STATS process_data(RECORD *dataset, int n) {    
    STATS stats = {  };
    stats.count = n;
    int count = n;
    float scores[MAX_LINE];


    float mean = 0;
    for (int i = 0; i < count; i++)
    {
        mean += dataset[i].score;
        scores[i] = dataset[i].score;
    }
    mean = mean / count ;

    float std = 0;
    for (int i = 0; i < count; i++)
    {
        std += (dataset[i].score - mean) * (dataset[i].score - mean);
    }
    std = sqrtf(std / count);

    float median;

    quick_sort(scores, 0, count -1);
    
    if (n % 2 == 1) //if it is odd 
    {
        median = scores[count / 2];
    }
    else
    { 
        median = (scores[count / 2 - 1] + scores[count / 2]) /2; 
    }
    stats.mean = mean;
    stats.stddev = std;
    stats.median = median;

    return stats;
    }



int import_data(char *infilename, RECORD *records) {
    FILE *fp = fopen(infilename, "r");
    char delimiters[] = ",\n\r";
    char line[100];

    int i = 0;
    char *token = NULL;

    while (fgets(line,sizeof(line),fp)!= NULL)
    {
        token = (char *) strtok(line, delimiters);
        strcpy(records[i].name, token);
        token = (char *) strtok(NULL, delimiters);
        records[i].score = atof(token);
        i++;
    }
    fclose(fp);
    return i;

}


int report_data(char *outfilename, RECORD *records, STATS stats) {
    int count = stats.count;
	FILE *fp = fopen(outfilename, "w");

	fprintf(fp, "stats:value\n");
	fprintf(fp, "count:%d\n", stats.count);
	fprintf(fp, "mean:%.1f\n", stats.mean);
	fprintf(fp, "stddev:%.1f\n", stats.stddev);
	fprintf(fp, "median:%.1f\n", stats.median);

	fprintf(fp, "\nname:score,grade\n");
	for (int i = 0; i < count; i++) {
		fprintf(fp, "%s:%.1f,%c\n", records[i].name, records[i].score,
				letter_grade(records[i].score));

	}
	fclose(fp);
	return 0;
}
