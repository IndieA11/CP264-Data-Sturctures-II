/*
-------------------------------------
File:    mysort.h
Project: Assignment 4
-------------------------------------
Author:  Indu Aujla 
ID:      2104349490
Email:   aujl9490@mylaurier.ca
-------------------------------------
*/
#ifndef MYSORT_H
#define MYSORT_H 

typedef enum {false, true} BOOLEAN;
BOOLEAN is_sorted(float *a, int left, int right);
void select_sort(float *a, int left, int right);
void quick_sort(float *a, int left, int right);

#endif