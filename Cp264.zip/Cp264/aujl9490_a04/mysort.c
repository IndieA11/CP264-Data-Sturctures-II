/*
-------------------------------------
File:    mysort.h
Project: Assignment 4
-------------------------------------
Author:  Indu Aujla 
ID:      2104349490
Email:   aujl9490@mylaurier.ca
-------------------------------------
*/

#include "mysort.h"

BOOLEAN is_sorted(float *a, int left, int right) {
	BOOLEAN result = true;
	int i = left;
	while (result && i < right)
    {
		if (*(a + i) > *(a + i + 1)) 
        {
			result = false;
		}
		i++;
	}
	return result;
}

void select_sort(float *a, int left, int right) {

	int i, j, k;
	int n = right - left + 1;
	for (i = 0; i < n; ++i) 
    {
        //set k equal to i 
		k = i;
		
        for (j = i + 1; j < n; ++j) 
        {
			if (*(a + j) < *(a + k)) 
            {
                //set k equal to j if j pointer value is greater than k
				k = j;
			}
		}
		if (i != k) 
        {
            //swapping the values in the sorted array 
			int temp = *(a + k);
			*(a + k) = *(a + i);
			*(a + i) = temp;
		}
	}

}

void quick_sort(float *a, int left, int right) {

	int i, j, k;
    float temp;
	float key;
	if (left < right) 
    {
		k = left;
		key = *(a + k);
		i = left + 1;
		j = right;
		while (i <= j) 
        {
			while (i <= right && *(a + i) <= key) 
            {
                //increment i 
				i++;
			}
			while (j >= left && *(a + j) > key) {
                //decrement j 
				j--;
			}
			if (i < j) 
            {
                //swapping the values in sorted array 
				temp = *(a + i);
				*(a + i) = *(a + j);
				*(a + j) = temp;
			}
		}
        //swapping the values in the sorted array 
		temp = *(a + left);
		*(a + left) = *(a + j);
		*(a + j) = temp;

        //call quicksort function 
		quick_sort(a, left, j - 1);
		quick_sort(a, j + 1, right);
	}
}
