/*
    JobID: cp264-a2
    Name: Indu Aujla 
    ID: 210349490
 */ 
#ifndef FIBONACCI_H
#define FIBONACCI_H

extern int *la;  // global pointer variable to hold lowest variable address

int iterative_fibonacci(int n)
{
    if (&n < la) la = &n;  // update the lowest memory address reached.
    int result;
    int fib1 = 0;
	int fib2 = 1;
	if(n == 0 || n == 1)
	{
		result = 1;
	}
	else
	{
	for(int i=1; i < n; i++)
	{
		result = fib1 + fib2;
		fib1 = fib2;
		fib2 = result;	
	}
	}
return(result);
}

int recursive_fibonacci(int n) {
    if (&n < la) la = &n;  // update the lowest memory address reached. 
    int result;
	if (n == 0 || n == 1){
		result = 1;
	}
    else{
		result = recursive_fibonacci(n-1) + recursive_fibonacci(n-2);
	}

}


#endif