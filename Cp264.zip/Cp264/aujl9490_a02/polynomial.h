/*
    JobID: cp264-a2
    Name: Indu Aujla 
    ID: 210349490
 */ 
#ifndef POLYNOMIAL_H
#define POLYNOMIAL_H
 
#include<stdio.h>
#include<math.h>

#define EPSILON 1e-6

float horner(float p[], int n, float x)
{
float out = 0;
    for(int i = 0; i < n; i++) //looping until we reach n value 
    {
        //add each iteration to itself and increment the exponenet by 1 each time 
        out += p[i]*powf(x, n-(i+1));
    }
    return out;
}

// compute the derivative of polynomial p[], and output to d[]
void derivative(float p[], int n, float d[]) {
// your implementation
    int i;
    float term;
    for (i = 0; i < n - 1; i++) { //loop through but decrment n every time 
        term = n - (i + 1);
        d[i] = term * p[i] * powf(1, term-1);
    }
    return;

}

float newton(float p[], int n, float x0) {
// your implementation
    float x = x0, px, d[n - 1];
    derivative(p, n, d);
    do {
        x0 = x;
        px = horner(p, n, x);
        x -= px / horner(d, n - 1, x);

    } while (fabs(x - x0) > EPSILON || fabs(px) > EPSILON);

    return x;

}

#endif /* POLYNOMIAL_H_ */