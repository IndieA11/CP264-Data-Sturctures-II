

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//===================== GLOBAL MACRO DEFINITIONS ==========================================================

#define  cNUL     '\0'          // NULL character
#define  sNUL     "\0"          // NULL String
#define  cBlank   ' '           // Blank character
#define  sBlank   " "           // Blank String
#define  cUScore  '_'           // Underscore character
#define  sUScore  "_"           // Underscore string.

// Define machine-independent TRUE and FALSE values
#ifdef TRUE
#undef TRUE
#undef FALSE
#endif
#define TRUE  (1==1)
#define FALSE (0==1)
// ======================== Statement Function Definitions.
#define  F_MIN(v1,v2) (((v1) <  (v2))? (v1):(v2))        // Return the less    of v1 and v2
#define  F_MAX(v1,v2) (((v1) >  (v2))? (v1):(v2))        // Return the greater of v1 and v2
#define ZF_MIN(v1,v2) (F_MAX(0, (F_MIN((v1),(v2)))))     // Like F_MIN, but lower bounds the result at ZERO
#define ZF(v)         (F_MAX(0, (v)))                    // Lower bounds the value "v" at ZERO.
#define  F_NOT(v)     (((v) == TRUE)? FALSE:TRUE)        // Logical Negation.
#define  F_ABS(v)     (((v) >= 0   )? (v):(-(v)))        // Absolute value

//====================== GLOBAL CONSTANTS ==================================================================
#define MAX_NUM_ROWS     5           // Max. number of rows.
#define MAX_NUM_COLS     6           // Max. number of columns.
#define MAX_KEY_PAIRS   15           // Max. number of [row, col] key pairs.

//<*** your GLOBAL CONSTANTS definitions here ***>

int main(int argc, char *argv[]) {
//==============================
    setbuf(stdout, NULL);            // Turns standard output buffering off

int index1 = 0;
int index2 = 0;


// "scrambled" - 2D Character Array storing adhoc characters.
    char scrambled[MAX_NUM_ROWS][MAX_NUM_COLS] = {{"zd_k83"},
                                                  {"Ju9_Tn"},
                                                  {"bgm7If"},
                                                  {"ax0DLU"},
                                                  {"p_QoiR"}                                                 };
 // "Key" - 2D Integer Array storing the message key pairs [row, col].
//         Note: The range of the row, col pair values stored in the "key"
 //               array is as shown below:
 //               [row, col] ==> [1...5, 1...6], not [0...4, 0...5]!!!
    int  key[MAX_KEY_PAIRS][2] = {{3,5}, // I
                                  {5,2}, // _
                                  {4,1}, // A
                                  {3,3}, // M
                                  {1,3}, // _ 
				                  {1,2}, // D
                                  {5,4}, // O
                                  {5,5}, // I
                                  {2,6}, // N
				                  {3,2}, // G 
			                      {2,4}, // _
				                  {4,5}, // L
                                  {4,1}, // A
				                  {3,1}, // B
                                  {1,6}  // 3                 
			                    };

    for(int j=0; j<=MAX_KEY_PAIRS; j++){
      index1=key[j][0];
      index2=key[j][1];
      char i = scrambled[index1-1][index2-1];
       if ( i == cUScore)
       {
          i = cBlank;
       }
      
      printf("%c", i);

      

   }
   
    

    return 0;
}

