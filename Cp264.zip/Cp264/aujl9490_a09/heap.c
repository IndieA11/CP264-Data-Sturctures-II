/*
 * your program signature
 */ 
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "heap.h"

HEAP* new_heap(int capacity) {
	HEAP *hp = (HEAP*) malloc(sizeof(HEAP));
	hp->capacity = capacity;
	hp->size = 0;
	hp->hna = (HEAPNODE*) malloc(sizeof(HEAPNODE) * capacity);
	return hp;
}

void swap_heap(HEAPNODE *a, HEAPNODE *b) {
	HEAPNODE dummy;
	dummy = *a;
	*a = *b;
	*b = dummy;
	return;
}

//heapify up starting from a
int up_heapify(HEAP *source, int a) {
	HEAPNODE *pointer = source->hna;

	int k = a;
	int j = (k - 1) / 2;

	while (k != 0)
   {
		if (cmp((pointer + j)->key, (pointer + k)->key) == 1) 
    {
			swap_heap((pointer + j), (pointer + k));
			k = j;
			j = (k - 1) / 2;
		} 
    else 
    {
			break;
		}
	}
	return k;
}

//helper heapify function starting from a
int down_heapify(HEAP *source, int a) {
	HEAPNODE *pointer = source->hna;

	int index = a, j;
	int right = 2 * index + 2;
	int left = 2 * index + 1;

	while (index < source->size) 
  {
		if (right >= source->size) 
    {
			if (left >= source->size) 
      {
				break;
			} 
      else
      {
				j = left;
			}
		} 
    else 
    {
			j = (cmp((pointer + left)->key, (pointer + right)->key) == -1) ?
					left : right;
		}

		if (cmp((pointer + j)->key, (pointer + index)->key) == -1) 
    {
			swap_heap((pointer + j), (pointer + index));
			index = j;
			left = 2 * index + 1;
			right = 2 * index + 2;
		} 
    else 
    {
			break;
		}
	}
	return index;
}

void make_heapify(HEAPNODE *hna, int n, int i) {

	int small = i;
	int left = 2 * i + 1;
	int right = 2 * i + 2;

	if (left < n && cmp(hna[left].key, hna[small].key) < 0) 
  {
		small = left;
	}

	if (right < n && cmp(hna[right].key, hna[small].key) < 0) 
  {
		small = right;
	}

	if (small != i) 
  {
		swap_heap(&hna[i], &hna[small]);
		make_heapify(hna, n, small);
	}
}

void insert(HEAP *heap, HEAPNODE new_node) {

	if (heap->size == heap->capacity)
   {
		heap->capacity *= 2;
		void *dummy = realloc(heap->hna, sizeof(HEAPNODE) * heap->capacity);
		if (dummy) 
    {
			heap->hna = dummy;
		} 
    else
    {
			dummy = malloc(sizeof(HEAPNODE) * heap->capacity);
			if (dummy) 
      {
				memcpy(dummy, heap->hna, sizeof(HEAPNODE) * heap->size);
				free(heap->hna);
				heap->hna = dummy;
			} 
      else 
      {
				printf("array resize failed\n");
			}
		}
	}

	HEAPNODE *pointer = heap->hna;
	*(pointer + heap->size) = new_node;
	heap->size++;
	up_heapify(heap, heap->size - 1);
	return;

}

HEAPNODE extract_min(HEAP *heap) {
	HEAPNODE *pointer = heap->hna;
	swap_heap(pointer, pointer + heap->size - 1);
	HEAPNODE result = *(pointer + heap->size - 1);
	heap->size--;
	down_heapify(heap, 0);

	if (heap->size <= heap->capacity / 4) 
  {
		heap->capacity /= 2; // this is to reset the capacity double
		void *dummy = realloc(heap->hna, sizeof(HEAPNODE) * heap->capacity);
		
    if (dummy) 
    {
			heap->hna = dummy;
		} 
    else
     {
			dummy = malloc(sizeof(HEAPNODE) * heap->capacity);
			if (dummy) 
      {
				memcpy(dummy, heap->hna, sizeof(HEAPNODE) * heap->size);
				free(heap->hna);
				heap->hna = dummy;
			} 
      else
      {
				printf("array resize failed\n");
			}
		}
	}

	return result;
}

int change_key(HEAP *heap, int index, KEYTYPE new_key) {

	HEAPNODE *pointer = heap->hna;
	KEYTYPE prev_key = (pointer + index)->key;
	(pointer + index)->key = new_key;

	int j;
	if (index == 0) 
  {
		j = down_heapify(heap, 0);
	} 
  else if (index == heap->size - 1) 
  {
		j = up_heapify(heap, heap->size - 1);
	} 
  else
  {
		if (cmp(prev_key, new_key) == -1)
    {
			j = down_heapify(heap, index);
		} 
    else if (cmp(prev_key, new_key) == 1)
    {
			j = up_heapify(heap, index);
		} 
    else 
    {
			j = index;
		}
	}
	return j;
}

int find_data_index(HEAP *heap, DATA data) {
	HEAPNODE *pointer = heap->hna;
	int index = 0;

	while (index < heap->size) {
		if ((pointer + index)->data == data) {
			break;
		} else {
			index++;
		}
	}

	return index;
}

void heap_sort(HEAPNODE *hna, int n) {
	for (int j = n / 2 - 1; j >= 0; j--) {
		make_heapify(hna, n, j);
	}

	for (int j = n - 1; j > 0; j--) {
		swap_heap(&hna[0], &hna[j]);
		make_heapify(hna, j, 0);
	}
}

int cmp(KEYTYPE a, KEYTYPE b) {
	int r = 0;
	if (a < b) r = -1;
	else if (a > b) r = 1;
	return r;
}

