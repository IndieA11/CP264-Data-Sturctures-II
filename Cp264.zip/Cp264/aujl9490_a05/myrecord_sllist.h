/*
-------------------------------------
File:    myrecord_sllist.h
Project: Assignment 5
-------------------------------------
Author:  Indu Aujla 
ID:      2104349490
Email:   aujl9490@mylaurier.ca
-------------------------------------
*/
 
#ifndef SLLIST_H
#define SLLIST_H

typedef struct {
  char name[40];
  float score;
} RECORD;

typedef struct node {
    RECORD data;
    struct node *next;
} NODE;

typedef struct sllist {
    int length;
    NODE *start;
} SLLIST;

NODE *search(SLLIST *sllistp, char *name);
void insert(SLLIST *sllistp, char *name, float score);
int delete(SLLIST *sllistp,  char *name);
void clean(SLLIST *sllistp);

#endif