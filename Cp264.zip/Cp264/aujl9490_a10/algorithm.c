/*
 * your program signature
 */ 

#include <stdio.h>
#include <stdlib.h> 
#include "heap.h"
#include "algorithm.h"



EDGELIST *mst_prim(GRAPH *g, int start) {
    if (g == NULL)
	return NULL;

    //initialize variables 
	int i = g->order;
    int heapindex = g->order;
    int n = g->order;
	int T[n], parent[n];
    //calling heapnode 
	HEAPNODE hn;

	for (i = 0; i < n; i++) 
    {
		T[i] = 0;
		parent[i] = -1;
	}

	HEAP *h = new_heap(4);
	ADJNODE *temp = g->nodes[start]->neighbor;
	T[start] = 1;
	while (temp) 
    {
		hn.key = temp->weight;
		hn.data = temp->nid;
		insert(h, hn); //call insert function 
		parent[temp->nid] = start;
		temp = temp->next;
	}
	EDGELIST *mst = new_edgelist();
	
    //while h size greater than zero 
	while (h->size > 0) 
    {
		hn = extract_min(h);
		i = hn.data;
		T[i] = 1;
		add_edge_end(mst, parent[i], i, hn.key);
		temp = g->nodes[i]->neighbor;
		while (temp) 
        {
            //call find data index fucntion for heap 
			heapindex = find_data_index(h, temp->nid);

            //if heap index is greater or equal to zero 
			if (heapindex >= 0) 
            {
				if (T[temp->nid] == 0 && temp->weight < h->hna[heapindex].key) 
                {
					change_key(h, heapindex, temp->weight);
					parent[temp->nid] = i;
				}
			} 
            else 
            {
				if (T[temp->nid] == 0) 
                {
					hn.key = temp->weight;
					hn.data = temp->nid;
                    //call insert function from heap 
					insert(h, hn);
					parent[temp->nid] = i;
				}
			}
			temp = temp->next;
		}
	}
	return mst;
}

EDGELIST *spt_dijkstra(GRAPH *g, int start) {
    if (!g) return NULL;
    EDGELIST *spt = new_edgelist();

    //intialize variables 
    int i= g->order;
    int heapindex = g->order;
    int u = g->order;
    int n = g->order;
    int T[n], parent[n], label[n];
    //create heap node 
    HEAPNODE hn;

    for (i = 0; i < n; i++) { T[i] = 0; label[i] = 9999; }

    //call new_heap function 
    HEAP *h = new_heap(4);
    label[start] = 0;
    T[start] = 1;
    u = start;
    
    while((g->order-1) - spt->size != 0)
    {
        ADJNODE *v = g->nodes[u]->neighbor;
        while(v)
        {
            if(label[u]+v->weight < label[v->nid])
            {
                label[v->nid] = label[u]+v->weight;
                parent[v->nid] = u;
                hn.key = v->weight + label[u];
                hn.data = v->nid;
                //call insert function 
                insert(h, hn);
            }
            v = v->next;
        }

        if(h->size != 0)
        {
            //call extract min function 
            hn = extract_min(h);
            if(label[hn.data] != 9999)
            {
                u = hn.data;
                T[u] = 1;
                label[u] = hn.key;
                add_edge_end(spt, parent[u], u, label[u]-label[parent[u]]);
            }
        }
    }

    return spt;
}

EDGELIST *sp_dijkstra(GRAPH *g, int start, int end) {
    if (!g) return NULL;
    EDGELIST *spt = new_edgelist();

    //intialize variables 
    int i = g->order;
    int heapindex = g->order;
    int u = g->order;
    int n = g->order;
    int T[n], parent[n], label[n];

    //create heap node 
    HEAPNODE hn;
    for (i = 0; i < n; i++) 
    { 
        T[i] = 0; label[i] = 9999; 
    }
    //call new heap function 
    HEAP *h = new_heap(4);
    label[start] = 0;
    T[start] = 1;

    u = start;
    
    while((g->order-1) - spt->size != 0)
    {
        ADJNODE *v = g->nodes[u]->neighbor;
        while(v)
        {
            if(label[u]+v->weight < label[v->nid])
            {
                label[v->nid] = label[u]+v->weight;
                parent[v->nid] = u;
                hn.key = v->weight + label[u];
                hn.data = v->nid;
                insert(h, hn);
            }
            v = v->next;
        }

        if(h->size != 0)
        {
            //call extract min fucntion 
            hn = extract_min(h);
            if(label[hn.data] != 9999)
            {
                u = hn.data;
                T[u] = 1;
                label[u] = hn.key;
                add_edge_end(spt, parent[u], u, label[u]-label[parent[u]]);
            }
        }
}
//creating new edgelist 
    EDGELIST *sp = new_edgelist();
        i = end;
        while (1) 
        {
        //if i equals start then break 
        if (i == start) break;

        add_edge_start(sp, parent[i], i, label[i]-label[parent[i]]);
        i = parent[i];
    }
    return sp;
}