/*
 * your program signature
 */ 

#include <stdio.h>
#include <stdlib.h> 
#include "edgelist.h"

EDGELIST *new_edgelist() {
    EDGELIST *p = malloc(sizeof(EDGELIST));
    p->size = 0;
	  p->start = NULL;
	  p->end = NULL;
    return p;
}

void add_edge_end(EDGELIST *g, int from, int to, int weight) {
  //memory and variables 
  EDGE *new_edge = (EDGE*) malloc(sizeof(EDGE));
	new_edge->from = from;
	new_edge->to = to;
	new_edge->weight = weight;
	new_edge->next = NULL;

  //if g to start equals null 
	if (g->start == NULL) 
  {
    //create new edge 
		g->start = new_edge;
	}
  else
  //next is the new edge 
	g->end->next = new_edge;
  //end is the new edge 
	g->end = new_edge;
  //increment size 
	g->size++; 
}

void add_edge_start(EDGELIST *g, int from, int to, int weight) {
  //memory and variables 
  EDGE *p = malloc(sizeof(EDGE));
  p->from = from;
  p->to = to;
  p->weight = weight;
  p->next = g->start;

  //if not g to start 
  if(!g->start)
  {
    g->end = p;
  }
  //increment size 
  g->size++;
  g->start = p;
}

int weight_edgelist(EDGELIST *g) {
 int weight = 0;
    EDGE *p = g->start;
    while(p){
        weight+=p->weight;
        p = p->next;
    }
    return weight;
}

void clean_edgelist(EDGELIST **gp) {
  EDGELIST *g = *gp;
  EDGE *value, *p = g->start;
  
  while (p) 
  {
    //set value and p equal 
    value = p;
    p = p->next;
    //free value 
    free(value); 
  }
  free(g);
  *gp = NULL;
}

void display_edgelist(EDGELIST *g) {
  if (g == NULL) return;
  printf("size:%d\n", g->size);
  printf("(from to weight):");
  EDGE *p = g->start;
  while (p) {
    printf("(%d %d %d) ", p->from, p->to, p->weight);
    p = p->next;
  }
}