/*
 * your program signature
 */ 

#include <stdio.h>
#include <stdlib.h>
#include "queue_stack.h" 
#include "graph.h"

GRAPH *new_graph(int order) {
  GRAPH *new = (GRAPH*) malloc(sizeof(GRAPH));
	new->order = order;
  //initialize size to zero
	new->size = 0; 
	new->nodes = malloc(order * sizeof(GNODE*));

	for (int i = 0; i < order; i++) 
  {
    //create GNODE 
		new->nodes[i] = malloc(sizeof(GNODE)); 
		new->nodes[i]->nid = i; 
		new->nodes[i]->neighbor = NULL; 
	}
	return new;
}

void add_edge(GRAPH *g, int from, int to, int weight) {
  ADJNODE *p = g->nodes[from]->neighbor;
  //set found to zero 
  int found = 0;

  if(p)
  {
    while(p->next)
    {
      if(p->nid == to)
      {
        //set found to 1 and break out of loop
        found = 1;
        break;
      }
      p = p->next;
    }
    if(p->nid == to)
    {
        //set found to 1 
        found = 1;
    }
    if(found)
    {
      p->weight = weight;
    } 
    else 
    {
      ADJNODE *n = malloc(sizeof(ADJNODE));
      //reassign n variables 
      n->next = NULL;
      n->nid = to;
      n->weight = weight;
      //reassign p->next to n 
      p->next = n;
    }
  } 
  else 
  {
    ADJNODE *n = malloc(sizeof(ADJNODE));
    //reassign n variables 
    n->next = NULL;
    n->nid = to;
    n->weight = weight;
    //reference neighbour linked list 
    g->nodes[from]->neighbor = n;
  }
  //increment size 
  g->size++;
}

int get_weight(GRAPH *g, int from, int to) {
  ADJNODE *p = g->nodes[from]->neighbor;
	int result = INFINITY;
	
  while (p) 
  {
		if (p->nid == to)
    {
      //set result to p weight then break 
			result = p->weight;
			break;
		}
    //set p to point to next 
		p = p->next;
	}
	return result;
}

void clean_graph(GRAPH **gp) {
  int i;
  GRAPH *g = *gp;
  ADJNODE *temp, *ptr;

  for (i = 0; i < g->order; i++) 
  {
    //reference linked neighbour list 
    ptr = g->nodes[i]->neighbor;

    //while the pointer is not null 
    while (ptr != NULL) 
    {
      //set temp to ptr
      temp = ptr;
      ptr = ptr->next;
      free(temp);
    }
    free(g->nodes[i]);
  }
  //free g and reset to null 
  free(g->nodes);
  free(g);
  *gp = NULL;
}
void display_bforder(GRAPH *g, int start) {
  //using queue stack data structure 
  if (g == NULL) return;
  int n = g->order, visited[n], i;
  for (i=0; i<n;i++) visited[i] = 0;
  //intilizae queue GNode and ADJ node 
  QUEUE queue = {0};
  GNODE *gnp = NULL;
  ADJNODE *anp = NULL;
  enqueue(&queue, g->nodes[start]);
  visited[start] = 1;

  while (queue.front) 
  {
    gnp = (GNODE*) dequeue(&queue);
    printf("%d ", gnp->nid);
    ADJNODE *p = gnp->neighbor;
    while(p)
    {
      if(!visited[p->nid])
      {
        //call enqueue and queue 
        enqueue(&queue, g->nodes[p->nid]);
        visited[p->nid] = 1;
      }
      p=p->next;
    }
  }
  //call clean queue 
  clean_queue(&queue);
}

void display_dforder(GRAPH *g, int start) {
//use queue stack data structure 
  if (g == NULL) return;
  int n = g->order, visited[n], i;
  for (i=0; i<n;i++) visited[i] = 0;

  STACK stack = {0};
  GNODE *gnp = NULL;
  ADJNODE *anp = NULL;
  push(&stack, g->nodes[start]);
  visited[start] = 1;

  while (stack.top) 
  {
    gnp = (GNODE*) stack.top->data;
    pop(&stack);
    printf("%d ", gnp->nid);
    ADJNODE *p = gnp->neighbor;
    while(p)
    {
      if(!visited[p->nid])
      {
        push(&stack, g->nodes[p->nid]);
        visited[p->nid] = 1;
      }
      p=p->next;
    }
  }
  clean_stack(&stack);
}

void display_graph(GRAPH *g) {
  if (g == NULL) return;
  printf("order:%d\n", g->order);
  printf("size:%d\n", g->size);
  printf("from:(to weight)");
  int i;
  ADJNODE *ptr;
  for (i = 0; i < g->order; i++) {
    printf("\n%d:", g->nodes[i]->nid);
    ptr = g->nodes[i]->neighbor;
    while (ptr != NULL) {
      printf("(%d %d) ", ptr->nid, ptr->weight);
      ptr = ptr->next;
    }
  }
}
