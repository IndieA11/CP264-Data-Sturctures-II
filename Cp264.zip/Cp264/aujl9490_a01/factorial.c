/**
--------------------------------------------------
Project: cp264-a1q1
File:    factorial.c
Author:  Indu Aujla
Version: January 2022
--------------------------------------------------
*/
#include <stdio.h>

int main(int argc, char *args[])
{  
  int number=0, x, factorial=1;
  int overflow = 0;

  if ( argc > 1 ) 
  {
    sscanf(args[1],"%d",&number); // this gets integer value from command line argument argv[1].  
    if (number >= 1){

        for (int i = 1; i<=number; i++)
        {
            x = factorial;
            factorial = factorial * i;

            if (x != (factorial/i))
            {
              overflow = 1;
              break;
            }
        }  
    }
    else
    {
        overflow = 2;
        printf("%s!:invalid\n",args[1]);
    }
  }

  else
  {
    printf("argument input:missing\n");
  }

  if(overflow == 1)
  {
    printf("%d!:overflow\n",number);
  }
  
  else if(overflow== 0)
  {
    printf("%d!:%d\n",number,factorial);
  } 
  
  return 0;
} 
