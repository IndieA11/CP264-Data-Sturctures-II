/**
--------------------------------------------------
Project: cp264-a1q1
File:    caseflip.c
Author:  Indu Aujla
Version: January 2022
--------------------------------------------------
*/

#include <stdio.h>
int main() {
  
  char c = 0, temp;

  do {
    printf("Please enter a character\n");
    scanf("%c", &c); //this is to get a character input from keyboard stdin.

    // flush the input buffer
    do { // this loop is to get rid of additional characters in stdin buffer
      scanf("%c", &temp);
      if (temp == '\n') break;
    } while (1);

    if (65 <= c && c <= 90)
    {
       printf("%c:%c\n", c, c+32);
    } 
    else if(97 <= c && c <=122){
    	printf("%c:%c\n", c, c-32);
    }
    else if (c =='*')
    {
        printf("%c:quit\n", c);
    }
    else
    {
    	printf("%c:invalid\n", c);
    }
  } while (c!= '*');
  
  return 0;
}
 