#include <stdio.h>
#include "stack.h"

void push(STACK *sp, NODE *np) {
    np->next = sp->top;
    sp->top = np;
    //increment height of stack 
    sp->height++;
}

NODE *pop(STACK *sp) {
    NODE *p = sp->top;
    
    if(!p)
    //underflow condition needed 
    {
        printf("UNDERFLOW");
    } 
    else 
    {
        sp->top = p->next;
        p->next = NULL;
        //decrement height of stack 
        sp->height--;
    }
    return p;
}

void clean_stack(STACK *sp) {
    //set height equal to zero 
    sp->height = 0;
    if(sp->top)
    {
        //call clean function from common file 
        clean(&sp->top);
    }
    //set top stack pointer to NULL 
    sp->top = NULL;
}