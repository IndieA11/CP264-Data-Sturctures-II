#include <stdio.h>
#include <stdlib.h>
#include "common.h"
#include "queue.h"

void enqueue(QUEUE *qp, NODE *np) {
    np->next = NULL;
    //if q node is the front 
    if(qp->front)
    {
        qp->rear->next = np;
        qp->rear = np;
    } 
    
    else 
    {
        qp->front = np;
        qp->rear = np;
    }
    //increment the q pointer length 
    qp->length++;
}  
  

NODE *dequeue(QUEUE *qp) {
    NODE *p = qp->front;
    if(p)
    {
        qp->front = p->next;
        p->next = NULL; //next node is null 
        
        if(!qp->front) //not at front 
        
        {
            qp->rear = NULL;
        }
        //decrement the q pointer length 
        qp->length--;
    } 
    else 
    //underflow condition 
    {
        printf("UNDERFLOW");
    }
    return p;
}


void clean_queue(QUEUE *qp) {

    qp->length = 0; //lenght equals 0 
    if(qp->front)
    {
        //call clean function from common file 
        clean(&qp->front);
    }
    //set front and rear to NULL 
    qp->front = NULL;
    qp->rear = NULL;
}
                     