//Inserting at the end in a singly Linked List 
    //Insert the node after the NULL pointer at the end of the linked list 
void insert_end(struct node **startp, int num) {
  //create the node with malloc 
    struct node *newnode = (struct node *) malloc(sizeof(struct node));
    //initialize fields 
    //new node -> data is num
    newnode->data = num;
    //newnode -> NULL
    newnode->next = NULL;

    //checking if theres data in the linked list 
    if (startp==NULL)
    {
        //the start node is the new node 
        startp = newnode;
    }
    else 
    {
        //creating a new pointer to the start of the list 
        struct node lastnode = *startp;

        //while the new node is not null
        while (lastnode->next != NULL)
        {
            //go to the next node 
            lastnode = lastnode->next;
        }
        lastnode->next = newnode;
    }
}
void insert_beg(struct node **startp, int num) {
    //initialize node structure 
  struct node* newnode = (struct node *)malloc(sizeof(struct node));

//if the new node is NULL
  if (newnode == NULL) 
{
    //intialize data fields 
    newnode->data = num;
    newnode->next = NULL; 
    
    //new node next is the starter 
    newode->next = *startp;
    //starter is now the new node 
    *startp = newnode;
}
}
//Tree Info - Practice Exam 
typdef struct TREEINFO
{
    int height;
    int leaf_count;

}TREEINFO;

TREEINFO treeinfo (TNODE *root)
{
    TREEINFO ans = {0};

//Base Case - if the left subtree and right subtree are NULL
if (root->left && root->right == NULL)
{
    //correpspond it the answer structure 
    ans.height = 1;
    ans.leaf_count = 1;
}
else 
{
    if (root->left) //looking at the left side 
    {
        TREEINFO ls = treeinfo(root->left);
    }
    else
    {
        TREEINFO ls == NULL;
    }
    if (root->right) //looking at the left side 
    {
        TREEINFO rs = treeinfo(root->right);
    }
    else
    {
        TREEINFO rs == NULL;
    }
    if (ls.height >= rs.height) //if left height is greater than right height 
    {
        ans.height = ls.height + 1;
    }
    else
    {
        ans.height = rs.heigth + 1;
    }
    ans.leaf_count = ls.leafcount + rs.leafcount;
}
return ans; 
}

//Depth First Search with a Tree
TNODE *depth_first_search(TNODE *root, int key) 
{
    //DFS uses a stack to initialize stack 
    STACK stack = {0};
    *peekval = NULL // peek is the top of the stack 
    *r = NULL //return

    if (root)
    {
        //push the root value on the stack 
        push(&stack, root); 

        while(stack->top) //while the stack has values in it 
        {
            peekval = pekk(&stack);

            if (p->data == key) //if the data equals the key 
            {
                r = peekval; //r is the peek value
                break;
            }
            pop(&stack);
            //if there is a right pointer push it on to the stack 
            if(p->right) 
            {
                push(&stack, p->right);
            }
            if (p->left)
            {
                push(&stack, p->left);
            }
        clean_stack(&stack);
        }
        return r;
    }
}

//Breadth First Search 
GNODE *breadth_first_search(GRAPH *g, int start, int key)
{
    int status[g->size];
    int i;
    for (i = 0; i < g->size; i++)
    {
        status[i] = 0;
    }
    //create structures 
    GNODE *graphnodep = NULL:
    ADJNODE *p;
    QUEUE queue = {0};

    //load root into the queue 
    enqueue(&queue, g->[start])

    status[start]=1; //set start to 1

    while (queue.front) //while the queue is not empty 
    {
        graphnodep = dequeue(&queue);

        if (gnp->data == key) //if the key is found
        {
            clean_queue(&queue);
            dnp = graphnodep;
            return grpahnodep;
        }
    p = graphnodep->neighbour; //if not found move to the neighbour node 
    while (p)
    {
        //visit the neighbour nodes 
        i = p->nid;
        if (status[p_>vertex]==0)
        {
            //queue the neighbour values 
            enqueue(&queue, g->nodes[i])
            p = p->next; //go to the next neighbour node 
        }
        clean_queue(&queue);
        return NULL;
    }
    }
}
//Heap Code 
int heapify_up(HEAPNODE *hna, int index) { //inserting 
  int parent; 
  HEAPNODE temp;
  while (index > 0) { //while the index is not the root 
    //formula for heapfiy up 
    parent = (index - 1) / 2 ;
    //comapare the parent with the index - if it is smaller we break out becsusae heapify is not needed 
    if (cmp(hna[parent].key, hna[index].key)<=0) break; 

	else { 
    //swap the parent with the index 
	  temp = hna[index]; //set temp to hna index 
      hna[index] = hna[parent]; //set heap node of index to heap node of parent 
	  hna[parent] = temp; //set parent to temp 
	  index = parent; //index is now the parent node 
	}
  }
  return index;
}

int heapify_down(HEAPNODE *hna, int n, int index) { //deletion 
  int child; 
  HEAPNODE temp;
  //if the index is less than the max/min size of the heap 
  while (index < n) {
    //heapify down formula 
    child = (index * 2 ) + 1;
    //if the child is greater than the max.min size
    if (child >= n) break;

    //if the child incrmented by 1 is less than n, comapre heapnode of child + 1.key and heapnode of child.key 
    //if the cmo is less than equal to zero increment child++
    if ((child + 1 < n) && cmp(hna[child + 1].key, hna[child].key)<=0) child++;
    //if the cmp of the index to the child is <= 0 then break 
    if (cmp(hna[index].key, hna[child].key)<=0) break;
    //swap index and child 
	temp = hna[index];
	hna[index] = hna[child];
	hna[child] = temp;
	index = child; //index becomes new child node 
  }
  return index;
}

//Inserting Hash Table 
int insert(HASHTABLE *ht, HASHNODE *np) {

	int index = hash(np->name);
	HASHNODE *pointer = *(ht->hna + index);
	int condition = 0, flag = 1;
	
	if (!pointer) 
	{
		*(ht->hna + index) = np;
		ht->count++;
	}
	else 
	{
		do 
		{
			if (strcmp(pointer->name, np->name) == 0) 
			{
				condition = 1;
				pointer->value = np->value;
			} 
			else 
			{
				if (pointer->next != NULL) 
				{
					pointer = pointer->next;
				} 
				else 
				{
					flag = 0;
				}
			}
		} while (!condition && pointer && flag);
		
		if (!condition) 
		{
			pointer->next = np;
			ht->count++;
		}
	}

	return !condition;

}
//structure to compute the incremental function 
typedef struct HASH{
    int inc;
}HASH
//Hash table word count 
void ht_insert(HashTable* table, char* key, char* value)
{
// Creates the word item 
Ht_item* item = create_item(key, value);

// Computes the index within the hash table using a hash function
int index = hash_function(key);

//current item is equal to the item at the index on the table - location of data for storing word 
Ht_item* current_item = table->items[index];

//if the current item is the same as what needs to go in it, increment the frequency 
//if it is colliding wit its own item 
if (current_item == item) table->items[index].inc += 1;

//if there is nothing in the table 
if (current_item == NULL)
{
    //table count is equal to the table size - hash table is full 
    if (table->count == table->size)
    {

        printf("Insert Error: Hash Table is full\n");
        free_item(item);
        return;
    }

    // Insert directly if there is an empty space 
    table->items[index] = item;
    //increment the count for the frequency of the word 
    table->count++;
}
}


