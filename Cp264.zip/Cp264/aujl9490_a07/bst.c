/*
-------------------------------------
Author:  Indu Aujla 
ID:      2104349490
Email:   aujl9490@mylaurier.ca
-------------------------------------
*/
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bst.h"

// you can add auxiliary function for the insert and delete operations

//create new node in the bst 
TNODE* new_node(char *name, float score) {

	TNODE *p = (TNODE*) malloc(sizeof(TNODE));
	RECORD r = { 0 };
	//copy sting name - with given name and score
	strcpy(r.name, name);
	r.score = score;
	p->data = r;
	p->left = NULL;
	p->right = NULL;
	return p;
}

//clean tree fucntion
void clean_tree(TNODE **rootp) {

	TNODE *p = *rootp;
	//if pointer is null 
	if (p != NULL) 
	{
		if (p->left != NULL) 
		{
			clean_tree(&p->left);
		}
		if (p->right != NULL) 
		{
			clean_tree(&p->right);
		}
		free(p);
	}
	*rootp = NULL;
}

//searches for data by name in bst 
TNODE* search(TNODE *root, char *name) {

	TNODE *curr = root;
	//initliaze key variable 
	int key = 0;
	//while key does not equal current value 
	while (!key && curr) {
		if (strcmp(curr->data.name, name) == 0) 
		{
			key = 1; //key to 1 
		} 
		else if (strcmp(curr->data.name, name) > 0) 
		{
			curr = curr->left; //current to left
		} 
		else 
		{
			curr = curr->right; // current to right 
		}
	}
	return curr;

}

void insert(TNODE **rootp, char *name, float score) {

	//new node to insert created 
	TNODE *newnp = new_node(name, score);
	if (*rootp == NULL) 
	{
		*rootp = newnp;
	} 
	else 
	{
		if (strcmp(newnp->data.name, (*rootp)->data.name) != 0) //does not equal zero, go through statements
		{
			if (strcmp(newnp->data.name, (*rootp)->data.name) < 0) 
			//less than zero 
			{
				insert(&(*rootp)->left, name, score);
			} 
			else if (strcmp(newnp->data.name, (*rootp)->data.name) > 0) 
			//greater than zero 
			{
				insert(&(*rootp)->right, name, score);
			}
		}
	}
}

/*aux function for delete method */
TNODE* extract_smallest_node(TNODE **rootp) {
	//itertaive method to find the smallest node 
	TNODE *p = *rootp, *parent = NULL;
	if (p) {
		while (p->left) {
			//set parent node to 
			parent = p;
			p = p->left;
		}

		//if parent node is equal to null
		if (parent == NULL)
			*rootp = p->right;
		else
			parent->left = p->right;

		p->left = NULL;
		p->right = NULL;
	}

	return p;
}

void delete(TNODE **rootp, char *name) {

	TNODE *current = *rootp, *child;
	TNODE **prev = NULL;

	//flag will tell if the value is found or not 
	int flag = 0; 

	//if current node is equal to null 
	if (current == NULL)
		return;
	//while current node is not equal to null and not flag
	while (current != NULL && !flag) 
	{

		if (strcmp(current->data.name, name) == 0) //string compare 
		{
			if (current->left == NULL && current->right == NULL) 
			{
				free(current); //free current node 
				*prev = NULL; //previous is null
			} 
			else if (current->left != NULL && current->right == NULL) 
			{
				child = current->left;
				*prev = child; //previous is a child node 
				free(current); //free current node 
			} 
			else if (current->left == NULL && current->right != NULL) 
			{
				child = current->right;
				*prev = child; //previous is a child node 
				free(current); //free current node 
			} 
			else if (current->left != NULL && current->right != NULL)
			{
				//call extract smallest node fnction to find the smallest node 
				child = extract_smallest_node(&current->right);
				child->left = current->left;
				child->right = current->right;
				*prev = child;
				free(current);
			}
			//set flag to 1 
			flag = 1;
		} 
		else 
		{
			if (strcmp(current->data.name, name) < 0) 
			{
				prev = &current->right;
				current = current->right;
			} 
			else 
			{
				prev = &current->left;
				current = current->left;
			}
		}
	}
}